rm "/data/adb/swap-config.txt"
